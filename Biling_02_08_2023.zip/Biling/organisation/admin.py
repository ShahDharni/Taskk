from django.contrib import admin
from .models import OrganisationDetails,CustomerDetails,Invoice_Details,Product
from django.contrib.auth import get_user_model


class OrganisationAdmin(admin.ModelAdmin):
    model = OrganisationDetails
    list_display = ['company_name','city','email']

class CustomerDetailsAdmin(admin.ModelAdmin):
    list_display = ['cust_name','contact_num','state']
    
admin.site.register(CustomerDetails,CustomerDetailsAdmin)
admin.site.register(OrganisationDetails,OrganisationAdmin)
admin.site.register(Invoice_Details)
admin.site.register(Product)
